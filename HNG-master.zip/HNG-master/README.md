# HNG

Link to Lucid Blog
https://lucid.blog/naza/post/machine-learning-task-0e9
